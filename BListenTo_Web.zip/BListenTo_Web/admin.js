lucide.createIcons();

// --- STATE MANAGEMENT ---
let posts = JSON.parse(localStorage.getItem('blistento_posts')) || [];
let categories = JSON.parse(localStorage.getItem('blistento_cats')) || ["Technology", "Lifestyle", "Business"];

// --- NAVIGATION LOGIC ---
function switchTab(tab) {
    document.getElementById('tab-articles').classList.toggle('hidden', tab !== 'articles');
    document.getElementById('tab-categories').classList.toggle('hidden', tab !== 'categories');
    
    // UI Feedback
    document.getElementById('btn-articles').className = tab === 'articles' ? 'w-full flex items-center space-x-3 text-white bg-indigo-600 p-3 rounded-lg' : 'w-full flex items-center space-x-3 text-slate-400 p-3';
    document.getElementById('btn-categories').className = tab === 'categories' ? 'w-full flex items-center space-x-3 text-white bg-indigo-600 p-3 rounded-lg' : 'w-full flex items-center space-x-3 text-slate-400 p-3';
}

// --- CATEGORY MANAGER LOGIC ---
function renderCategories() {
    const list = document.getElementById('categoryList');
    const select = document.getElementById('postCategory');
    
    // Update Sidebar List
    list.innerHTML = categories.map(cat => `
        <li class="flex justify-between items-center p-2 bg-slate-50 rounded-lg border border-slate-100">
            <span class="font-medium text-slate-700">${cat}</span>
            <button onclick="deleteCategory('${cat}')" class="text-red-400 hover:text-red-600"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
        </li>
    `).join('');

    // Update Dropdown in Article Editor
    select.innerHTML = categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    
    localStorage.setItem('blistento_cats', JSON.stringify(categories));
    lucide.createIcons();
}

function addCategory() {
    const input = document.getElementById('newCatInput');
    const val = input.value.trim();
    if (val && !categories.includes(val)) {
        categories.push(val);
        input.value = '';
        renderCategories();
    }
}

function deleteCategory(cat) {
    categories = categories.filter(c => c !== cat);
    renderCategories();
}

// --- ARTICLE CRUD LOGIC ---
function renderAdminTable() {
    const tableBody = document.getElementById('adminTableBody');
    tableBody.innerHTML = posts.map(post => `
        <tr>
            <td class="px-6 py-4 font-medium">${post.title}</td>
            <td class="px-6 py-4 text-slate-500">${post.category}</td>
            <td class="px-6 py-4 text-right">
                <button onclick="editPost(${post.id})" class="text-indigo-600 mr-3">Edit</button>
                <button onclick="deletePost(${post.id})" class="text-red-600">Delete</button>
            </td>
        </tr>
    `).join('');
}

document.getElementById('postForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('editId').value;
    const title = document.getElementById('postTitle').value;
    const category = document.getElementById('postCategory').value;
    const content = document.getElementById('postContent').value;
    const imageFile = document.getElementById('postImage').files[0];
    const date = new Date().toLocaleDateString();

    let imageData = "";

    // If a new image is uploaded, convert it to Base64
    if (imageFile) {
        imageData = await toBase64(imageFile);
    } else if (id) {
        // If editing and no new image, keep the old one
        const existingPost = posts.find(p => p.id == id);
        imageData = existingPost.image || "";
    }

    if (id) {
        const index = posts.findIndex(p => p.id == id);
        posts[index] = { ...posts[index], title, category, content, image: imageData };
    } else {
        posts.push({ id: Date.now(), title, category, content, date, image: imageData });
    }

    localStorage.setItem('blistento_posts', JSON.stringify(posts));
    toggleModal();
    renderAdminTable();
});

// Helper function to convert file to Base64 string
const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});
function deletePost(id) {
    if(confirm('Delete article?')) {
        posts = posts.filter(p => p.id !== id);
        localStorage.setItem('blistento_posts', JSON.stringify(posts));
        renderAdminTable();
    }
}

function editPost(id) {
    const post = posts.find(p => p.id == id);
    document.getElementById('editId').value = post.id;
    document.getElementById('postTitle').value = post.title;
    document.getElementById('postCategory').value = post.category;
    document.getElementById('postContent').value = post.content;
    toggleModal();
}

function toggleModal() {
    document.getElementById('modal').classList.toggle('hidden');
    if (document.getElementById('modal').classList.contains('hidden')) document.getElementById('postForm').reset();
}

// Initialize
renderCategories();
renderAdminTable();