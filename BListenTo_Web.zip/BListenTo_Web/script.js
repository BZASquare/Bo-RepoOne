// Initialize Lucide Icons
lucide.createIcons();

// Comment Functionality
const commentsList = document.getElementById('commentsList');
const commentInput = document.getElementById('commentInput');

function addComment() {
    const text = commentInput.value.trim();
    
    if (text === "") {
        alert("Please enter a comment!");
        return;
    }

    const commentHTML = `
        <div class="flex gap-4 p-4 border-b border-slate-100 new-comment">
            <div class="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-white font-bold">U</div>
            <div>
                <h4 class="font-bold text-sm">Guest User</h4>
                <p class="text-slate-600 text-sm mt-1">${text}</p>
            </div>
        </div>
    `;

    commentsList.insertAdjacentHTML('afterbegin', commentHTML);
    commentInput.value = "";
}

// Simple logic to simulate "Modern" loading
window.addEventListener('load', () => {
    console.log('BListenTo: Website fully functional and production-ready.');
});